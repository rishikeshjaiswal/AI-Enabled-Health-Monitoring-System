from locust import HttpUser, task, between
import random

def sample():
    if random.random() < 0.1:
        return {"heart_rate": random.uniform(30, 49), "spo2": random.uniform(80, 91),
                "temp_c": random.uniform(38.6, 41.0), "motion": random.choice([0,1])}
    else:
        return {"heart_rate": random.uniform(60, 100), "spo2": random.uniform(95, 100),
                "temp_c": random.uniform(36.1, 37.5), "motion": random.choice([0,1])}

class APIUser(HttpUser):
    wait_time = between(0.1, 1.0)

    @task
    def predict(self):
        self.client.post("/predict", json=sample())
