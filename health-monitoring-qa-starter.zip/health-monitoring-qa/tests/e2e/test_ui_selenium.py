import os, pytest, time, json, requests
from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.by import By

pytestmark = pytest.mark.e2e

def test_api_smoke():
    # This is a placeholder e2e that hits the API like a user would via UI.
    # Replace with real UI later; here we just post to API and assert.
    url = "http://127.0.0.1:8000/predict"
    payload = {"heart_rate":90,"spo2":99,"temp_c":36.6,"motion":0}
    try:
        r = requests.post(url, json=payload, timeout=3)
        assert r.status_code in (200, 503)
    except Exception as e:
        pytest.skip(f"API not running: {e}")
