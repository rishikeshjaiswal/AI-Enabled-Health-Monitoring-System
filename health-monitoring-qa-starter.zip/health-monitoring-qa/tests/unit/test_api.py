import json, pytest
from app.api import app

@pytest.fixture(scope="module")
def client():
    app.config.update({"TESTING": True})
    with app.test_client() as client:
        yield client

def test_health(client):
    r = client.get("/health")
    assert r.status_code == 200
    assert "status" in r.get_json()

def test_predict_valid(client, monkeypatch):
    # Ensure model is loaded for tests
    with app.app_context():
        # Trigger before_first_request
        for f in app.before_first_request_funcs:
            f()
    payload = {"heart_rate":85,"spo2":98,"temp_c":36.9,"motion":0}
    r = client.post("/predict", json=payload)
    assert r.status_code in (200, 503)  # 503 if model not trained yet
