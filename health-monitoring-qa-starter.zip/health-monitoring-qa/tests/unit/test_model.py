import os, json
from app.model import HealthModel

def test_model_can_predict_after_training():
    m = HealthModel()
    n_prob = m.predict_proba({"heart_rate":80,"spo2":98,"temp_c":36.8,"motion":0})
    a_prob = m.predict_proba({"heart_rate":140,"spo2":88,"temp_c":39.2,"motion":1})
    assert 0.0 <= n_prob <= 1.0
    assert 0.0 <= a_prob <= 1.0
    assert a_prob > n_prob, "Anomaly should have higher probability than normal"
