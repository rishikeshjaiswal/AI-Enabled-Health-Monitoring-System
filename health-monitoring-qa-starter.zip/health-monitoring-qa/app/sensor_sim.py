import time, random, json, requests

API = "http://127.0.0.1:8000/predict"

def sample_vitals():
    # Mostly normal ranges with occasional anomalies
    if random.random() < 0.1:  # 10% anomalies
        return {
            "heart_rate": random.choice([random.uniform(30, 49), random.uniform(121, 180)]),
            "spo2": random.uniform(80, 91),
            "temp_c": random.uniform(38.6, 41.0),
            "motion": random.choice([0,1])
        }
    else:
        return {
            "heart_rate": random.uniform(60, 100),
            "spo2": random.uniform(95, 100),
            "temp_c": random.uniform(36.1, 37.5),
            "motion": random.choice([0,1])
        }

def stream(interval=1.0):
    while True:
        v = sample_vitals()
        try:
            r = requests.post(API, json=v, timeout=3)
            print("Sent:", v, "| API:", r.status_code, r.text[:120])
        except Exception as e:
            print("Error posting to API:", e)
        time.sleep(interval)

if __name__ == "__main__":
    stream(1.0)
