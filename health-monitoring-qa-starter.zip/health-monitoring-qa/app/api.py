from __future__ import annotations
from flask import Flask, jsonify, request
from pydantic import BaseModel, Field, ValidationError
from app.model import HealthModel

app = Flask(__name__)
model = None

class Vitals(BaseModel):
    heart_rate: float = Field(..., ge=20, le=220)
    spo2: float = Field(..., ge=50, le=100)
    temp_c: float = Field(..., ge=30, le=45)
    motion: int = Field(0, ge=0, le=1)

@app.before_first_request
def load_model():
    global model
    try:
        model = HealthModel()
    except Exception as e:
        app.logger.error(str(e))
        model = None

@app.get("/health")
def health():
    return jsonify({"status": "ok", "model_loaded": model is not None})

@app.post("/predict")
def predict():
    if model is None:
        return jsonify({"error": "model not loaded. Train it (python ml/train.py) and restart API."}), 503
    try:
        data = Vitals(**request.get_json(force=True)).dict()
    except ValidationError as ve:
        return jsonify({"error": "validation_failed", "details": ve.errors()}), 400

    proba = model.predict_proba(data)
    label = int(proba >= 0.5)
    return jsonify({"anomaly_probability": proba, "anomaly_label": label, "input": data})

if __name__ == "__main__":
    app.run(port=8000)
