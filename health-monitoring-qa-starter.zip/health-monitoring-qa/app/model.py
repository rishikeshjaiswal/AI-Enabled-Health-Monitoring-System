from __future__ import annotations
from pathlib import Path
import joblib
import numpy as np

MODEL_PATH = Path(__file__).resolve().parents[1] / "ml" / "model.joblib"

class HealthModel:
    def __init__(self, model_path: Path = MODEL_PATH):
        if not model_path.exists():
            raise FileNotFoundError(f"Model not found at {model_path}. Train it with `python ml/train.py`.")
        self.clf = joblib.load(model_path)

    def predict_proba(self, features: dict) -> float:
        x = np.array([[
            float(features["heart_rate"]),
            float(features["spo2"]),
            float(features["temp_c"]),
            float(features.get("motion", 0))
        ]])
        # Probability of anomaly (class 1)
        proba = self.clf.predict_proba(x)[0][1]
        return float(proba)

    def predict_label(self, features: dict) -> int:
        x = np.array([[
            float(features["heart_rate"]),
            float(features["spo2"]),
            float(features["temp_c"]),
            float(features.get("motion", 0))
        ]])
        return int(self.clf.predict(x)[0])
