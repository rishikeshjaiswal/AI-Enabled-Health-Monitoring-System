from __future__ import annotations
import numpy as np, pandas as pd
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import train_test_split
from sklearn.metrics import classification_report
from pathlib import Path
import joblib, random

OUT = Path(__file__).resolve().parent / "model.joblib"

def generate_synthetic(n=5000, anomaly_rate=0.15, seed=42):
    rng = np.random.default_rng(seed)
    rows = []
    for _ in range(n):
        is_anom = rng.random() < anomaly_rate
        if is_anom:
            hr = rng.choice([rng.uniform(30, 49), rng.uniform(121, 180)])
            spo2 = rng.uniform(80, 91)
            temp = rng.uniform(38.6, 41.0)
        else:
            hr = rng.uniform(60, 100)
            spo2 = rng.uniform(95, 100)
            temp = rng.uniform(36.1, 37.5)
        motion = rng.integers(0, 2)
        label = int((hr < 50) or (hr > 120) or (spo2 < 92) or (temp > 38.5))
        rows.append((hr, spo2, temp, motion, label))
    df = pd.DataFrame(rows, columns=["heart_rate","spo2","temp_c","motion","label"])
    return df

def main():
    df = generate_synthetic()
    X = df[["heart_rate","spo2","temp_c","motion"]].values
    y = df["label"].values
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=7, stratify=y)
    clf = RandomForestClassifier(n_estimators=200, random_state=7, class_weight="balanced")
    clf.fit(X_train, y_train)
    print(classification_report(y_test, clf.predict(X_test)))
    OUT.parent.mkdir(parents=True, exist_ok=True)
    joblib.dump(clf, OUT)
    print(f"Saved model to {OUT}")

if __name__ == "__main__":
    main()
