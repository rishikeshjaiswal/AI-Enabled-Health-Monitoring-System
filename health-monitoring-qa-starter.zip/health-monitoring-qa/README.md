# Automated QA Framework for AI-Enabled Health Monitoring System (Python)

This starter implements:
- **Sensor simulation** (synthetic vitals)
- **ML model** (anomaly detection)
- **REST API** (Flask) to score vitals
- **Unit tests** (pytest)
- **E2E UI test (optional)** with Selenium
- **Load testing** with Locust
- **CI** (GitHub Actions) sample

## Quick Start

### 1) Create virtual env & install deps
```bash
python -m venv .venv
source .venv/bin/activate  # Windows: .venv\Scripts\activate
pip install -r requirements.txt
```

### 2) Train the model
```bash
python ml/train.py
# saves: ml/model.joblib
```

### 3) Run the API
```bash
FLASK_APP=app/api.py flask run --port 8000
# API:
#   GET  /health
#   POST /predict  (JSON body: {heart_rate, spo2, temp_c, motion})
```

### 4) Try a request
```bash
curl -X POST http://127.0.0.1:8000/predict -H "Content-Type: application/json" -d '{"heart_rate":85,"spo2":97,"temp_c":36.9,"motion":0}'
```

### 5) Run tests
```bash
pytest -q
# Optional E2E UI (requires running API): pytest -q -m e2e
```

### 6) Load test with Locust
```bash
locust -f load/locustfile.py
# Open http://127.0.0.1:8089 and set Host to http://127.0.0.1:8000
```

### 7) CI
Copy `.github/workflows/ci.yml` into your GitHub repo to run tests on every push.

---

## Project Structure
```
health-monitoring-qa/
├─ app/
│  ├─ api.py           # Flask API
│  ├─ model.py         # Load/use model
│  ├─ sensor_sim.py    # Synthetic vitals generator
├─ ml/
│  ├─ train.py         # Train and save model
│  ├─ model.joblib     # (created after training)
├─ tests/
│  ├─ unit/
│  │  ├─ test_model.py
│  │  └─ test_api.py
│  ├─ e2e/
│  │  └─ test_ui_selenium.py
├─ load/
│  └─ locustfile.py
├─ .github/workflows/
│  └─ ci.yml
├─ requirements.txt
└─ README.md
```

## Notes
- The ML task is a simple **anomaly detector** using rules to label synthetic data; a RandomForest learns patterns.
- Improve realism by swapping in actual sensor streams (MQTT) or recorded datasets.
- Extend the UI/dashboard and add more Selenium tests as needed.
